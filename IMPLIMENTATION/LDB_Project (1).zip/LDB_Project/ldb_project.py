# TEST DATA - Car and Driver Data set
cars = [
    {'id': 1, 'brand': 'Toyota', 'price': 25000, 'mileage': 30, 'year': 2020},
    {'id': 2, 'brand': 'Honda', 'price': 28000, 'mileage': 32, 'year': 2021},
    {'id': 3, 'brand': 'BMW', 'price': 45000, 'mileage': 25, 'year': 2022},
    {'id': 4, 'brand': 'Ford', 'price': 22000, 'mileage': 28, 'year': 2019},
    {'id': 5, 'brand': 'Tesla', 'price': 50000, 'mileage': 35, 'year': 2023},
    {'id': 6, 'brand': 'Mazda', 'price': 26000, 'mileage': 31, 'year': 2021}
]
drivers = [
    {'id': 1, 'name': 'Alice',   'age': 28, 'experience': 6,  'rating': 4.7, 'accidents': 0},
    {'id': 2, 'name': 'Bob',     'age': 45, 'experience': 20, 'rating': 4.3, 'accidents': 2},
    {'id': 3, 'name': 'Charlie', 'age': 34, 'experience': 10, 'rating': 4.9, 'accidents': 1},
    {'id': 4, 'name': 'Diana',   'age': 26, 'experience': 4,  'rating': 4.5, 'accidents': 0},
    {'id': 5, 'name': 'Ethan',   'age': 52, 'experience': 30, 'rating': 4.1, 'accidents': 3},
    {'id': 6, 'name': 'Fiona',   'age': 31, 'experience': 8,  'rating': 4.6, 'accidents': 1}
]

#PREFERENCE DEFINITIONS

# Implements Prefrence Base Class
class Preference:
    def __init__(self, name, better_than_func):
        self.name = name
        self.better_than = better_than_func # User defines the function based on which comparison happens.

    def dominates(self, a, b):
        return self.better_than(a, b)  # Returns boolean values True or False

# Define individual preferences

# Prefer cheaper car
lower_price = Preference(
    "Lower Price",
    lambda a, b: a['price'] < b['price']
)

# Prefer cars with higher milaege
higher_mileage = Preference(
    "Higher Mileage",
    lambda a, b: a['mileage'] > b['mileage']
)
# Prefer new car
newer_year = Preference(
    "Newer Year",
    lambda a, b: a['year'] > b['year']
)
# Chooses the driver with higher rating
better_driver = Preference(
    "Better Driver",
    lambda a, b: a['rating'] > b['rating']
)

# PREFERENCE COMPOSITION

class ParetoComposition:
    def __init__(self, preferences):
        self.preferences = preferences
        self.name = "Pareto(" + ", ".join([p.name for p in preferences]) + ")"

    def dominates(self, a, b):
        better_in_some = False
        for pref in self.preferences:
            if pref.dominates(b, a): # Checks if a is dominated by b at least in one prefrences
                return False
            if pref.dominates(a, b): # Checks if b is dominated by a in at least one prefrences
                better_in_some = True
        return better_in_some

class PrioritizedComposition:
    def __init__(self, preferences):       # Here the order in which prefrences are entered matter as first prefrence which occurs is more prefreed for comparison than the other
        self.preferences = preferences
        self.name = "Prioritized(" + " > ".join([p.name for p in preferences]) + ")"

    def dominates(self, a, b):
        for pref in self.preferences:
            if pref.dominates(a, b):  # Checks if the b is dominated by a in the first prefrences in the list of the preferences
                return True
            if pref.dominates(b, a):  # Checks if the a is dominated by b in the first prefrences in the list of the preferences
                return False
        return False



#Pareto Compositon class over R1 X R2

class ParetoComposition2:

    # Pareto composition over two relation schemata R1 × R2.

    def __init__(self, pref1, pref2):  # Takes single prefrences at a time not a list.
        self.pref1 = pref1  # preference over R1
        self.pref2 = pref2  # preference over R2
        self.name = f"Pareto2({pref1.name}, {pref2.name})"

    def dominates(self, a, b):
        """
        a = (t1, t2)
        b = (t1', t2')
        """
        t1, t2 = a
        t1p, t2p = b

        # X ⪰ Y  ≡  X ≻ Y or X ∼ Y
        not_worse_1 = not self.pref1.dominates(t1p, t1) # Checks if first tuple of a is dominated by first tuple of b.
        not_worse_2 = not self.pref2.dominates(t2p, t2) # Checks if second tuple of a is dominated by second tuple of b.

        better_1 = self.pref1.dominates(t1, t1p) # Checks if a dominates b by considering the first element of the tuple.
        better_2 = self.pref2.dominates(t2, t2p) # Checks if a dominates b by considering the second element of the tuple.

        return (not_worse_1 and not_worse_2) and (better_1 or better_2) # By the defination of Pareto Composition on R1 X R2.


class LexicographicalComposition:
    """
    Lexicographical composition over two relation schemata R1 × R2
    """
    def __init__(self, pref1, pref2):  # The order in which prefrences are entered matters.
        self.pref1 = pref1  # primary preference (R1)
        self.pref2 = pref2  # secondary preference (R2)
        self.name = f"Lex({pref1.name}, {pref2.name})" ## For printing purposes only.

    def dominates(self, a, b):
        """
        a = (t1, t2)
        b = (t1', t2')
        """
        t1, t2 = a
        t1p, t2p = b

        # t1 ≻ t1'
        if self.pref1.dominates(t1, t1p): # If t1p is dominated by t1 returns true i.e then a dominates b.
            return True

        # t1 ∼ t1'  ∧  t2 ≻ t2'
        indifferent_1 = (
            not self.pref1.dominates(t1, t1p)
            and not self.pref1.dominates(t1p, t1) # Checks if t1p is not dominated by t1 i.e. b does not dominate a.
        )

        return indifferent_1 and self.pref2.dominates(t2, t2p) # if t2 dominates t2p then a dominates b if the two conditions in the indifferent_1 is true.


# For Joining the two dataset1 and dataset 2. (This could have been definied in the class Paretocomposition2 and LexicographicalComposition  itself.)
def JOIN (dataset1 ,dataset2):
    return [(x,y) for x in dataset1 for y in dataset2]


# WINNOW OPERATOR IMPLEMENTATION

def winnow(dataset, preference):
    result = []

    for candidate in dataset:
        is_dominated = False

        for other in dataset:
                                                        # Compare only if the objects in the data set are not the same.
                                                        # Using 'is not' to check for object identity.
              if candidate is not other:
                if preference.dominates(other, candidate): # Checks if the candidate is dominated by even a single other element.
                    is_dominated = True
                    break

        if not is_dominated:
            result.append(candidate)                         # Only if the candiate is not dominated by any other element in the data set then append in the
                                                             # result list of winnow operator.
    return result

def print_result(title, result, preference_name):
    print(f"{title}")
    print(f"Preference: {preference_name}")
    for car in result:
        print(f"{car['id']}. {car['brand']:10} Price: ${car['price']:5} Mileage: {car['mileage']}mpg Year: {car['year']}")
    print()


print("DEFINED PREFERENCES")
print("1. Lower Price    : prefer cars with lower price")
print("2. Higher Mileage : prefer cars with better fuel efficiency")
print("3. Newer Year     : prefer newer cars")
print("4. Better Driver  : prefer driver with higher ratings")

# APPLY WINNOW OPERATOR WITH DIFFERENT PREFERENCES


result1 = winnow(cars, lower_price)
print_result("Winnow(Cars, Lower Price)", result1, lower_price.name)

result2 = winnow(cars, higher_mileage)
print_result("Winnow(Cars, Higher Mileage)", result2, higher_mileage.name)

prio_pref = PrioritizedComposition([newer_year, lower_price])
result3 = winnow(cars, prio_pref)
print_result("Winnow(Cars, Prioritized(Year > Price))", result3, prio_pref.name)


dataset = JOIN (cars , drivers)
pareto_pref2 = ParetoComposition2(lower_price , better_driver)
result4 = winnow(dataset , pareto_pref2)
print("Pareto Composition Over Cars and Driver Relation")
print("Preference: Lower Price, Better Driver")
print(result4)


lexo_pref = LexicographicalComposition(lower_price, better_driver)
result5 = winnow(dataset, lexo_pref)
print("Lexicographical Composition Over Cars and Driver Relation")
print("Preference: Lower Price, Better Driver")
print(result5)